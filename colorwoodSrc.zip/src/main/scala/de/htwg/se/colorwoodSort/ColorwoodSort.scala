package de.htwg.se.colorwoodSort
import de.htwg.se.colorwoodSort.model.*
import de.htwg.se.colorwoodSort.controller.*
import de.htwg.se.colorwoodSort.Aview.*

/** ------------------------------------------------------ main method to run the game ----------------------------------------------
  */

object colorwoodSort {
  val eol = "\n"
  def main(args: Array[String]): Unit = {

    Aview.View.startGame(3, height = 4, colorStrings = List("R", "G", "Y"))

  }
}

/** --------------------------------------------------------------------------------------------------------------
  */
